# 🌙 Acode Lua Samp Autocomplete

Auto-complete plugin for [Acode](https://acode.foxdebug.com/) that adds autocomplete suggestions for functions in **MoonLoader** and **MonetLoader**.

Author: Epang

Community: [Discord](https://discord.gg/6WGtywPt55)

Tiktok: [Tiktok](https://www.tiktok.com/@epang133?_t=ZS-8yIPQ2CgTED&_r=1)

GitHub: [Github](https://github.com/epangg)
